### Hexlet tests and linter status:
[![Actions Status](https://github.com/NikolayZemelko/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/NikolayZemelko/python-project-50/actions)
[![Actions Status](https://github.com/NikolayZemelko/python-project-50/workflows/main-check/badge.svg)](https://github.com/NikolayZemelko/python-project-50/actions)
[![asciicast](https://asciinema.org/a/A5cuYdluxwbfK8gcOKmCgPWb9.svg)](https://asciinema.org/a/A5cuYdluxwbfK8gcOKmCgPWb9)
